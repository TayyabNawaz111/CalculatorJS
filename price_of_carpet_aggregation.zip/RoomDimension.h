#include "feetInches.h"

class RoomDimensions{
	feetInches length;
	feetInches width;
public:
	RoomDimensions(float, float);
	RoomDimensions();
	void setLength(float);
	void setWidth(float);
	float getL();
	float getW();
	feetInches area();
};