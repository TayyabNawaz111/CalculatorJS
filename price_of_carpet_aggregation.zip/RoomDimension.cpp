#include "RoomDimension.h"

RoomDimensions::RoomDimensions(float a, float b) :length(a), width(b){}
RoomDimensions::RoomDimensions(){}

feetInches RoomDimensions::area(){
	feetInches temp =  (this->length.getInches()*this->width.getInches());
	return temp;
}

void RoomDimensions::setLength(float a){
	this->length.setInches(a);
}
void RoomDimensions::setWidth(float a){
	this->width.setInches(a);

}

float RoomDimensions::getL(){
	return this->length.getInches();
}

float RoomDimensions::getW(){
	return this->width.getInches();

}