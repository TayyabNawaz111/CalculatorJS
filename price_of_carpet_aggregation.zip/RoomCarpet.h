#include "RoomDimension.h"
class RoomCarpet{
	RoomDimensions *a = new RoomDimensions;
	double cost;
public:
	RoomCarpet();
	RoomCarpet(float l, float w, double cost);
	double ttlCost();
	~RoomCarpet(){
		delete a;
	}
};