#include "RoomCarpet.h"

int main(){

	RoomCarpet r(12.0, 10.0, 8.0);
	cout << r.ttlCost() << endl;

	system("pause");
	return 0;
}