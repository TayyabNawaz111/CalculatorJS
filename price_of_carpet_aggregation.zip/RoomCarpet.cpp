#include "RoomCarpet.h"

RoomCarpet::RoomCarpet(){}
RoomCarpet::RoomCarpet(float l, float w, double cost){
	a->setLength(l);
	a->setWidth(w);
	this->cost = cost;
}
double RoomCarpet::ttlCost(){
	return (this->a->getL()*this->a->getW()*this->cost);
}