#include "feetInches.h"
void feetInches::setInches(float a){
	if (a > 0){
		this->inches = a;
	}
	else{}
}
float feetInches::getInches(){
	return inches;
}
feetInches::feetInches(){}
feetInches::feetInches(float a){
	if (a > 0){
		this->inches = a;
	}
	else{}
}