#include <iostream>
using namespace std;
class feetInches{
	float inches;
public:
	void setInches(float);
	float getInches();
	feetInches::feetInches();
	feetInches::feetInches(float);
};